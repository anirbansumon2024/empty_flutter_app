package com.ottking.app.flutter_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
