package com.ottking.ltv.ottking_ltv

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
